package com.example.doctorapp

const val NEW_NOTE_ID =  0
const val TAG = "noteLogging"